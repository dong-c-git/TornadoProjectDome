create view v_goods_info as
  select
    `g`.`id`         AS `id`,
    `g`.`name`       AS `name`,
    `g`.`cate_id`    AS `cate_id`,
    `g`.`brand_id`   AS `brand_id`,
    `g`.`price`      AS `price`,
    `g`.`is_show`    AS `is_show`,
    `g`.`is_saleoff` AS `is_saleoff`,
    `c`.`name`       AS `cate_name`,
    `b`.`name`       AS `brand_name`
  from ((`test01`.`goods` `g` left join `test01`.`goods_cates` `c` on ((`g`.`cate_id` = `c`.`id`))) left join
    `test01`.`goods_brands` `b` on ((`g`.`brand_id` = `b`.`id`)));

